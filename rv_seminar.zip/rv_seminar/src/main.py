import cv2
import matplotlib.pyplot as plt
import numpy as np
import os

# Folderi
IMG_FOLDER = r"C:\Users\PC\Desktop\rv_seminar\data\images"
MASK_FOLDER = r"C:\Users\PC\Desktop\rv_seminar\data\masks"
RESULT_FOLDER = r"C:\Users\PC\Desktop\rv_seminar\results"

if not os.path.exists(RESULT_FOLDER):
    os.makedirs(RESULT_FOLDER)

# Učitavanje slika
img_files = [f for f in os.listdir(IMG_FOLDER) if f.endswith(".bmp")]

# Rule-based segmencija s morgologijom
def segment_image(img):
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    # PRAGIRANJE
    _, mask = cv2.threshold(gray, 128, 255, cv2.THRESH_BINARY)
    # MORFOLOŠKA OBRADA
    kernel = np.ones((5,5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    return mask

for img_file in img_files:
    img_path = os.path.join(IMG_FOLDER, img_file)
    mask_file = img_file.replace(".bmp", "_anno.bmp")
    mask_path = os.path.join(MASK_FOLDER, mask_file)

    img = cv2.imread(img_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    if os.path.exists(mask_path):
        gt = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
    else:
        gt = None

    #NAPRAVI MASKU RULE-BASED
    mask = segment_image(img)

    plt.figure(figsize=(12,4))

    plt.subplot(1,3,1)
    plt.title("Original")
    plt.imshow(img)
    plt.axis("off")

    plt.subplot(1,3,2)
    plt.title("Rule-based mask")
    plt.imshow(mask, cmap="gray")
    plt.axis("off")

    if gt is not None:
        plt.subplot(1,3,3)
        plt.title("Ground truth")
        plt.imshow(gt, cmap="gray")
        plt.axis("off")
    
    plt.savefig(r"C:\Users\PC\Desktop\rv_seminar\results\vis_" + img_file.replace(".bmp", ".png"))
    plt.close()

#SPREMI MASKU U RESULTS
result_path = os.path.join(RESULT_FOLDER, f"mask_{img_file}")
cv2.imwrite(result_path, mask)

print("Maske su spremljene u 'results' folder.")